from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/in/bhajan/bfpbusinesspro/MainActivity.kt").read_text()
gradle = (root / "app/build.gradle.kts").read_text()
checks = {
    "invoice editor uses one continuous scroll body": "addView(bodyScroll, LinearLayout.LayoutParams(-1, 0, 1f))" in main,
    "separate old item-list viewport removed": "itemListViewport" not in main and "bottomDetails" not in main,
    "item counter remains visible and updates": "val itemCountButton = Button" in main and 'itemCountButton.text = "${rows.size} आइटम"' in main,
    "voice parser fills name quantity and rate": "parseVoiceItemPhrase(spoken)" in main and "draftName.setText(parsed.first)" in main and 'draftQty.setText(parsed.second ?: "1")' in main and "draftRate.setText(it)" in main,
    "voice adds complete item and keeps listening": "val added = commitDraftLine()" in main and "if (added) { voiceStatus" in main and "startNextVoiceEntry = { if (continuousVoiceEntry) beginContinuousVoice() }" in main,
    "invoice remains explicitly saved by user": 'setNeutralButton("Save Bill", null)' in main and "dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener" in main,
    "Room schema remains unchanged": "version = 10" in (root / "app/src/main/java/in/bhajan/bfpbusinesspro/data/BfpDatabase.kt").read_text(),
    "app version is 5.54.0": 'versionCode = 554' in gradle and 'versionName = "5.54.0"' in gradle,
}
for label, ok in checks.items(): print(("PASS" if ok else "FAIL") + ": " + label)
assert all(checks.values())
print("DEV77/110 continuous billing + voice checks: PASS")
