from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/in/bhajan/bfpbusinesspro/MainActivity.kt').read_text(encoding='utf-8')
stock = (root / 'app/src/main/java/in/bhajan/bfpbusinesspro/data/StockRepository.kt').read_text(encoding='utf-8')
checks = {
    'new stock item dialog exposes Save & New': 'setNeutralButton("सेव और नया", null)' in main,
    'Save & New is wired to keep the dialog open': 'getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { saveItem(true) }' in main,
    'successful Save & New clears fields for next item': 'if (andNew && existing == null)' in main and 'code.text.clear(); name.text.clear(); category.text.clear()' in main,
    'new stock item uses transactional opening-stock repository': 'StockRepository(db).insertItemWithOpeningStock(entity)' in main and 'database.withTransaction' in stock,
    'ordinary Save still closes the dialog': 'dialog.dismiss()' in main,
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
print(f'DEV109: {sum(checks.values())}/{len(checks)} checks passed')
