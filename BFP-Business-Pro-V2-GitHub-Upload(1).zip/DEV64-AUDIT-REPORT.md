# BFP Business Pro AI Edition – Dev64 Source Audit

Audit date: 2026-11-19
Source inspected: `BFP-Business-Pro-AI-Edition-Dev64-Source(1)(1)-1-1 (1).zip`

## Findings and changes

1. The Dev52 supplier-rate regression verifier expected a SQL window-function implementation (`ROW_NUMBER()`), while the actual DAO intentionally uses a Room-compatible correlated subquery and `NOT EXISTS` latest-row selection. Dev64's own verifier explicitly requires avoiding window functions. This was a contradictory test, not a demonstrated accounting/query defect. Updated the Dev52 verifier to check the actual implementation and retain its SQLite fixture proving latest-vs-previous rates.
2. The GitHub Actions artifact labels still said `5.0`, although the app source is version `5.19.0` (versionCode 519). Updated both APK and Room-schema artifact names and added build-readiness assertions for those names.

## Verification

- `python tools/verify_all.py`: PASS (all bundled source-level checks, 54 Room DAO SQL checks, invoice-number SQL, posting invariants, integrated audit, Day Book checks, manifest XML, and CI configuration checks).
- Android Gradle build, unit-test task, and lint task: NOT RUN in this environment because Gradle is not installed and the source archive does not include a Gradle wrapper (`gradlew`). The GitHub Actions workflow is configured to install Gradle 8.9 and run those tasks.
- Physical Android device testing: NOT PERFORMED.

## Important scope note

This is a source-level audit and CI packaging correction. It is not a claim that an APK was built or that every screen was physically tested. No Room schema migration or accounting-posting logic was changed in this audit.
