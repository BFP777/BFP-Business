plugins { id("com.android.application") }

android {
    namespace = "in.bhajan.bfpbusiness"
    compileSdk = 35
    defaultConfig {
        applicationId = "in.bhajan.bfpbusiness"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
