package in.bhajan.bfpbusiness;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout list; TextView balanceView;
    public void onCreate(Bundle b) { super.onCreate(b); db=new DB(this); showHome(); }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t; }
    EditText edit(String hint, int type){ EditText e=new EditText(this); e.setHint(hint); e.setInputType(type); return e; }
    void showHome(){
        LinearLayout page=new LinearLayout(this); page.setOrientation(1); page.setPadding(dp(16),dp(12),dp(16),dp(12));
        page.setBackgroundColor(0xFFF7F7F7);
        TextView title=text("BHAJAN FASHION POINT",22); title.setTypeface(null,Typeface.BOLD); page.addView(title);
        page.addView(text("Business Accounting",16));
        balanceView=text("Cash Balance: ₹"+db.balance(),18); balanceView.setTypeface(null,Typeface.BOLD); page.addView(balanceView);
        LinearLayout actions=new LinearLayout(this);
        Button sale=btn("Sale / जमा"); sale.setOnClickListener(v->entry("SALE"));
        Button purchase=btn("Purchase / खर्च"); purchase.setOnClickListener(v->entry("PURCHASE"));
        actions.addView(sale,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(purchase,new LinearLayout.LayoutParams(0,-2,1)); page.addView(actions);
        LinearLayout actions2=new LinearLayout(this);
        Button receipt=btn("Cash Receipt"); receipt.setOnClickListener(v->entry("RECEIPT"));
        Button payment=btn("Cash Payment"); payment.setOnClickListener(v->entry("PAYMENT"));
        actions2.addView(receipt,new LinearLayout.LayoutParams(0,-2,1)); actions2.addView(payment,new LinearLayout.LayoutParams(0,-2,1)); page.addView(actions2);
        Button ledger=btn("Party Ledger / सभी एंट्री"); ledger.setOnClickListener(v->showEntries()); page.addView(ledger);
        page.addView(text("हाल की एंट्री",18));
        ScrollView sc=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(1); sc.addView(list); page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(page); loadRecent();
    }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    void entry(String type){
        LinearLayout box=new LinearLayout(this); box.setOrientation(1);
        EditText party=edit("Party / ग्राहक का नाम",1), amount=edit("रकम (₹)",2), note=edit("विवरण",1);
        box.addView(party); box.addView(amount); box.addView(note);
        new AlertDialog.Builder(this).setTitle(type+" Entry").setView(box)
          .setNegativeButton("रद्द",null).setPositiveButton("Save",(d,w)->{
            String p=party.getText().toString().trim(), a=amount.getText().toString().trim();
            if(a.isEmpty()){toast("रकम भरें");return;}
            try { double value=Double.parseDouble(a); if(value<=0) throw new Exception();
              db.add(type,p,value,note.getText().toString());
              showHome(); toast("एंट्री सेव हो गई");
            } catch(Exception ex){toast("सही रकम डालें");}
          }).show();
    }
    void loadRecent(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT type,party,amount,note,dt FROM entries ORDER BY id DESC LIMIT 30",null);
        while(c.moveToNext()){
            String line=c.getString(0)+" | "+c.getString(1)+" | ₹"+c.getString(2)+"\n"+c.getString(3)+" • "+c.getString(4);
            TextView row=text(line,14); row.setBackgroundColor(0xFFFFFFFF); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(6); list.addView(row,lp);
        } c.close();
    }
    void showEntries(){ showHome(); }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"bfp_business.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT,party TEXT,amount REAL,note TEXT,dt TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void add(String type,String party,double amount,String note){
            ContentValues v=new ContentValues(); v.put("type",type); v.put("party",party); v.put("amount",amount); v.put("note",note);
            v.put("dt",new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date())); getWritableDatabase().insert("entries",null,v);
        }
        double balance(){
            Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN type IN ('SALE','RECEIPT') THEN amount ELSE -amount END),0) FROM entries",null);
            double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;
        }
    }
}
