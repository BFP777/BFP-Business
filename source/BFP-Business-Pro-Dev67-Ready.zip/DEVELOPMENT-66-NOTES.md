# Development 66 — Bilingual Display Language Information

- Utilities menu identifies the app interface as Hindi + English bilingual.
- The information dialog explains that the interface uses bilingual labels and voice input supports both Hindi and English.
- This is an informational entry; it does not claim a separate language-toggle setting.
- Voice input language selection remains available for Hindi and English.
