# Dev105 GitHub Actions Kotlin compile error fixes

Applied fixes based on the uploaded GitHub Actions screenshot:

1. Removed accidentally copied `stockAdjustmentDialog(existing)` neutral-button handlers from employee, salary-month, salary-payment, party, and payment dialogs. The stock adjustment handler remains only in the Item editor where `existing` is an `ItemEntity`.
2. Made the nullable invoice GST parse safe before checking the 0..100 range.
3. Made the automatic backup file name null-safe before recording backup history.
4. Retained `BfpDatabase` as a property in `ReportsRepository`, because `financialStatement()` also uses it to reconcile money balances.

No database schema or version changes were made. Existing Dev105 checks pass: dashboard outstanding, package hygiene, posting invariants, and backup encryption.

Important: a full Android Gradle build was not run in this environment. The next GitHub Actions run is required to confirm compilation and may reveal any additional compiler errors.
