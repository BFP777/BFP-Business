package `in`.bhajan.bfpbusinesspro.backup

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import `in`.bhajan.bfpbusinesspro.data.BfpDatabase
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** Local ZIP backup/restore containing SQLite data and purchase attachments; legacy SQLite restore remains supported. */
object DatabaseBackup {
    private const val DB_NAME = "bfp_business_pro_5.db"
    private val SQLITE_HEADER = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)

    @Synchronized
    fun export(context: Context, destination: Uri) {
        val db = BfpDatabase.get(context)
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { cursor ->
            if (cursor.moveToFirst()) require(cursor.getInt(0) == 0) { "डेटाबेस बैकअप के लिए व्यस्त है; कृपया फिर कोशिश करें" }
        }
        BfpDatabase.closeForMaintenance()
        try {
            val source = context.getDatabasePath(DB_NAME)
            require(source.isFile && source.length() > 0L) { "डेटाबेस फाइल उपलब्ध नहीं है" }
            context.contentResolver.openOutputStream(destination, "w").use { raw ->
                requireNotNull(raw) { "बैकअप फाइल नहीं खुल सकी" }
                java.util.zip.ZipOutputStream(raw).use { zip ->
                    zip.putNextEntry(java.util.zip.ZipEntry("database/$DB_NAME"))
                    FileInputStream(source).use { it.copyTo(zip) }
                    zip.closeEntry()
                    val attachments = File(context.filesDir, "purchase_attachments")
                    if (attachments.exists()) attachments.walkTopDown().filter { it.isFile }.forEach { file ->
                        val relative = file.relativeTo(attachments).invariantSeparatorsPath
                        zip.putNextEntry(java.util.zip.ZipEntry("attachments/$relative"))
                        FileInputStream(file).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
        } finally { BfpDatabase.get(context) }
    }

    @Synchronized
    fun restore(context: Context, sourceUri: Uri) {
        val rawTemp = File(context.cacheDir, "bfp_restore_input.tmp")
        val extractDir = File(context.cacheDir, "bfp_restore_package")
        val legacyDb = File(context.cacheDir, "bfp_restore_legacy.db")
        val target = context.getDatabasePath(DB_NAME)
        val staging = File(target.parentFile, "$DB_NAME.restore-new")
        val previous = File(target.parentFile, "$DB_NAME.restore-previous")
        val targetAttachments = File(context.filesDir, "purchase_attachments")
        val stagedAttachments = File(context.filesDir, "purchase_attachments.restore-new")
        val previousAttachments = File(context.filesDir, "purchase_attachments.restore-previous")
        try {
            context.contentResolver.openInputStream(sourceUri).use { input ->
                requireNotNull(input) { "चुनी गई फाइल पढ़ी नहीं जा सकी" }
                FileOutputStream(rawTemp).use { output ->
                    val buffer = ByteArray(8192); var total = 0L
                    while (true) {
                        val count = input.read(buffer); if (count < 0) break
                        total += count
                        require(total <= 260L * 1024L * 1024L) { "चुनी गई बैकअप फाइल 260 MB से बड़ी है" }
                        output.write(buffer, 0, count)
                    }
                    output.fd.sync()
                }
            }
            val isZip = rawTemp.inputStream().use { it.read() == 0x50 && it.read() == 0x4B }
            val databaseSource: File
            if (isZip) {
                if (extractDir.exists()) extractDir.deleteRecursively()
                require(extractDir.mkdirs()) { "अस्थायी restore फोल्डर नहीं बन सका" }
                var totalBytes = 0L
                java.util.zip.ZipInputStream(FileInputStream(rawTemp)).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        val normalized = entry.name.replace('\\', '/')
                        require(!normalized.startsWith('/') && normalized.split('/').none { it == ".." }) { "बैकअप में असुरक्षित फाइल पथ है" }
                        require(normalized.startsWith("database/") || normalized.startsWith("attachments/")) { "बैकअप में अनजान सामग्री मिली" }
                        val out = File(extractDir, normalized)
                        require(out.canonicalPath.startsWith(extractDir.canonicalPath + File.separator)) { "बैकअप फाइल पथ गलत है" }
                        if (entry.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { output ->
                                val buffer = ByteArray(8192)
                                while (true) {
                                    val count = zip.read(buffer); if (count < 0) break
                                    totalBytes += count
                                    require(totalBytes <= 250L * 1024L * 1024L) { "बैकअप 250 MB से बड़ा है" }
                                    output.write(buffer, 0, count)
                                }
                            }
                        }
                        zip.closeEntry()
                    }
                }
                databaseSource = File(extractDir, "database/$DB_NAME")
                val attachmentSource = File(extractDir, "attachments")
                if (stagedAttachments.exists()) stagedAttachments.deleteRecursively()
                if (attachmentSource.exists()) {
                    attachmentSource.copyRecursively(stagedAttachments, overwrite = true)
                    require(stagedAttachments.exists()) { "अटैचमेंट restore नहीं हो सके" }
                }
            } else {
                rawTemp.copyTo(legacyDb, overwrite = true)
                databaseSource = legacyDb
                if (stagedAttachments.exists()) stagedAttachments.deleteRecursively()
                // Legacy SQLite backups did not contain attachment files.
            }
            validateBackup(databaseSource)
            target.parentFile?.mkdirs()
            if (staging.exists()) require(staging.delete()) { "अस्थायी restore फाइल हटाई नहीं जा सकी" }
            databaseSource.copyTo(staging, overwrite = true)
            validateBackup(staging)

            if (previous.exists()) require(previous.delete()) { "पुरानी सुरक्षा कॉपी हटाई नहीं जा सकी" }
            if (previousAttachments.exists()) require(previousAttachments.deleteRecursively()) { "पुरानी अटैचमेंट सुरक्षा कॉपी हटाई नहीं जा सकी" }
            BfpDatabase.closeForMaintenance()
            var oldDbMoved = false
            var oldAttachmentsMoved = false
            try {
                File(context.getDatabasePath("$DB_NAME-wal").path).delete()
                File(context.getDatabasePath("$DB_NAME-shm").path).delete()
                if (target.exists()) { require(target.renameTo(previous)) { "मौजूदा डेटाबेस सुरक्षित नहीं किया जा सका" }; oldDbMoved = true }
                if (targetAttachments.exists()) { require(targetAttachments.renameTo(previousAttachments)) { "मौजूदा अटैचमेंट सुरक्षित नहीं हो सके" }; oldAttachmentsMoved = true }
                require(staging.renameTo(target)) { "नई डेटाबेस फाइल स्थापित नहीं हो सकी" }
                if (stagedAttachments.exists()) require(stagedAttachments.renameTo(targetAttachments)) { "नए अटैचमेंट स्थापित नहीं हो सके" }
                BfpDatabase.get(context).openHelper.writableDatabase
                previous.delete(); previousAttachments.deleteRecursively()
            } catch (failure: Exception) {
                BfpDatabase.closeForMaintenance()
                if (target.exists()) target.delete()
                if (targetAttachments.exists()) targetAttachments.deleteRecursively()
                if (oldDbMoved && previous.exists()) previous.renameTo(target)
                if (oldAttachmentsMoved && previousAttachments.exists()) previousAttachments.renameTo(targetAttachments)
                BfpDatabase.get(context)
                throw failure
            }
        } finally {
            rawTemp.delete(); legacyDb.delete(); staging.delete(); extractDir.deleteRecursively(); stagedAttachments.deleteRecursively()
        }
    }

    private fun validateBackup(file: File) {
        require(file.isFile && file.length() > SQLITE_HEADER.size) { "बैकअप फाइल खाली या अधूरी है" }
        val header = ByteArray(SQLITE_HEADER.size)
        FileInputStream(file).use { input ->
            require(input.read(header) == header.size && header.contentEquals(SQLITE_HEADER)) {
                "यह मान्य BFP SQLite बैकअप नहीं है"
            }
        }
        val checkDb = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            checkDb.rawQuery("PRAGMA integrity_check", null).use { cursor ->
                require(cursor.moveToFirst() && cursor.getString(0) == "ok") { "बैकअप डेटाबेस की जाँच असफल रही" }
            }
            checkDb.rawQuery("PRAGMA user_version", null).use { cursor ->
                require(cursor.moveToFirst() && cursor.getInt(0) in 3..9) {
                    "बैकअप का डेटाबेस संस्करण समर्थित नहीं है (3 से 8)"
                }
            }
            val requiredTables = setOf("parties", "items", "invoices", "invoice_lines", "payments", "cash_entries", "business_profile")
            val foundTables = mutableSetOf<String>()
            checkDb.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { cursor ->
                while (cursor.moveToNext()) foundTables += cursor.getString(0)
            }
            require(foundTables.containsAll(requiredTables)) { "बैकअप में जरूरी BFP डेटा टेबल मौजूद नहीं हैं" }
            checkDb.rawQuery("PRAGMA user_version", null).use { cursor ->
                if (cursor.moveToFirst() && cursor.getInt(0) >= 7) {
                    require(foundTables.containsAll(setOf("employees", "salary_months", "salary_payments"))) { "बैकअप में कर्मचारी/वेतन टेबल अधूरी हैं" }
                }
            }
        } finally {
            checkDb.close()
        }
    }

}
