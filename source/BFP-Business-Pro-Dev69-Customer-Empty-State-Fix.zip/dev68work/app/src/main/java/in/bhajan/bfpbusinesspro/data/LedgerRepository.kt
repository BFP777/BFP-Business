package `in`.bhajan.bfpbusinesspro.data

import kotlinx.coroutines.flow.first

/** Read-only unified view of source transactions. It never creates duplicate ledger/day-book rows. */
class LedgerRepository(private val database: BfpDatabase) {
    private val dao = database.dao()

    data class LedgerRow(
        val dateEpochMillis: Long,
        val reference: String,
        val description: String,
        /** Positive = party owes shop; negative = shop owes party. */
        val debitPaise: Long,
        val creditPaise: Long,
        val balancePaise: Long
    )

    data class DayBookRow(
        val dateEpochMillis: Long,
        val reference: String,
        val description: String,
        val mode: String,
        val debitPaise: Long,
        val creditPaise: Long
    )

    data class DayBookSummary(
        val openingCashPaise: Long,
        val cashInPaise: Long,
        val cashOutPaise: Long,
        val closingCashPaise: Long,
        val rows: List<DayBookRow>
    )


    /** Current cash balance in paise, using only cash-mode movements. */
    suspend fun currentCashBalancePaise(): Long {
        val payments = dao.observePayments().first().filter { it.mode == "CASH" }
        val entries = dao.observeCashEntries().first().filter { it.mode == "CASH" }
        val salaryOut = dao.observeSalaryPayments().first().filter { it.mode == "CASH" }.sumOf { it.amountPaise }
        val paymentNet = payments.sumOf { if (it.direction == "IN") it.amountPaise else -it.amountPaise }
        val entryNet = entries.sumOf { when (it.entryType) {
            "OPENING", "CASH_WITHDRAWAL" -> it.amountPaise
            else -> -it.amountPaise
        } }
        return paymentNet + entryNet - salaryOut
    }

    /** Current UPI balance: UPI receipts minus UPI payments and UPI expenses. */
    suspend fun upiBalancePaise(): Long {
        val payments = dao.observePayments().first().filter { it.mode == "UPI" }
        val upiEntries = dao.observeCashEntries().first().filter { it.mode == "UPI" }
        val salaryOut = dao.observeSalaryPayments().first().filter { it.mode == "UPI" }.sumOf { it.amountPaise }
        val paymentNet = payments.sumOf { if (it.direction == "IN") it.amountPaise else -it.amountPaise }
        val entryNet = upiEntries.sumOf { entry -> when (entry.entryType) {
            "OPENING" -> entry.amountPaise
            "EXPENSE" -> -entry.amountPaise
            else -> 0L
        } }
        return paymentNet + entryNet - salaryOut
    }

    /** Current bank balance in paise. Cash deposits increase bank; cash withdrawals reduce it. */
    suspend fun bankBalancePaise(): Long {
        val payments = dao.observePayments().first().filter { it.mode == "BANK" }
        val entries = dao.observeCashEntries().first()
        val salaryOut = dao.observeSalaryPayments().first().filter { it.mode == "BANK" }.sumOf { it.amountPaise }
        val paymentNet = payments.sumOf { if (it.direction == "IN") it.amountPaise else -it.amountPaise }
        val entryNet = entries.sumOf { entry -> when {
            entry.mode == "BANK" && entry.entryType == "OPENING" -> entry.amountPaise
            entry.mode == "BANK" && entry.entryType == "EXPENSE" -> -entry.amountPaise
            entry.entryType == "CASH_DEPOSIT" -> entry.amountPaise
            entry.entryType == "CASH_WITHDRAWAL" -> -entry.amountPaise
            else -> 0L
        } }
        return paymentNet + entryNet - salaryOut
    }

    /** Bank balance isolated to one named account. */
    suspend fun bankAccountBalancePaise(bankAccountId: Long): Long {
        val payments = dao.observePayments().first().filter { it.mode == "BANK" && it.bankAccountId == bankAccountId }
        val entries = dao.observeCashEntries().first().filter { it.bankAccountId == bankAccountId }
        val salaryOut = dao.observeSalaryPayments().first().filter { it.mode == "BANK" && it.bankAccountId == bankAccountId }.sumOf { it.amountPaise }
        val paymentNet = payments.sumOf { if (it.direction == "IN") it.amountPaise else -it.amountPaise }
        val entryNet = entries.sumOf { entry -> when {
            entry.mode == "BANK" && entry.entryType == "OPENING" -> entry.amountPaise
            entry.mode == "BANK" && entry.entryType == "EXPENSE" -> -entry.amountPaise
            entry.entryType == "CASH_DEPOSIT" -> entry.amountPaise
            entry.entryType == "CASH_WITHDRAWAL" -> -entry.amountPaise
            else -> 0L
        } }
        return paymentNet + entryNet - salaryOut
    }

    suspend fun partyLedger(partyId: Long): List<LedgerRow> {
        require(dao.observeParties().first().any { it.id == partyId }) { "पार्टी नहीं मिली" }
        val invoices = (dao.observeInvoices("SALE").first() + dao.observeInvoices("PURCHASE").first())
            .filter { it.partyId == partyId }
        val payments = dao.getPartyPayments(partyId)
        data class Entry(val date: Long, val ref: String, val desc: String, val debit: Long, val credit: Long, val id: Long)
        val entries = mutableListOf<Entry>()
        invoices.forEach { inv ->
            val sale = inv.kind == "SALE"
            entries += Entry(inv.dateEpochMillis, inv.invoiceNumber, if (sale) "बिक्री बिल" else "खरीद बिल",
                if (sale) inv.totalPaise else 0L, if (sale) 0L else inv.totalPaise, inv.id)
        }
        payments.forEach { p ->
            val isIn = p.direction == "IN"
            entries += Entry(p.dateEpochMillis, "PAY-${p.id}", if (isIn) "प्राप्त भुगतान (${p.mode})" else "किया गया भुगतान (${p.mode})",
                if (isIn) 0L else p.amountPaise, if (isIn) p.amountPaise else 0L, 1_000_000_000L + p.id)
        }
        var balance = 0L
        return entries.sortedWith(compareBy<Entry> { it.date }.thenBy { it.id }).map { e ->
            balance += e.debit - e.credit
            LedgerRow(e.date, e.ref, e.desc, e.debit, e.credit, balance)
        }
    }

    suspend fun dayBook(fromEpochMillis: Long, toEpochMillis: Long): DayBookSummary {
        require(fromEpochMillis <= toEpochMillis) { "तारीख की सीमा गलत है" }
        val sales = dao.observeInvoices("SALE").first()
        val purchases = dao.observeInvoices("PURCHASE").first()
        val payments = dao.observePayments().first()
        val salaryPayments = dao.observeSalaryPayments().first()
        val employees = dao.observeEmployees().first().associate { it.id to it.name }
        val cashEntries = dao.observeCashEntries().first()
        val bankNames = dao.observeBankAccounts().first().associate { it.id to it.accountName }
        val all = mutableListOf<DayBookRow>()
        sales.filter { it.dateEpochMillis in fromEpochMillis..toEpochMillis }.forEach {
            all += DayBookRow(it.dateEpochMillis, it.invoiceNumber, "बिक्री बिल दर्ज — ₹${it.totalPaise / 100.0}", "BILL", 0L, 0L)
        }
        purchases.filter { it.dateEpochMillis in fromEpochMillis..toEpochMillis }.forEach {
            all += DayBookRow(it.dateEpochMillis, it.invoiceNumber, "खरीद बिल दर्ज — ₹${it.totalPaise / 100.0}", "BILL", 0L, 0L)
        }
        payments.filter { it.dateEpochMillis in fromEpochMillis..toEpochMillis }.forEach { p ->
            val incoming = p.direction == "IN"
            val bankLabel = if (p.mode == "BANK") p.bankAccountId?.let(bankNames::get)?.let { " — $it" }
                ?: " — बैंक खाता उपलब्ध नहीं" else ""
            all += DayBookRow(p.dateEpochMillis, "PAY-${p.id}", (if (incoming) "Payment In" else "Payment Out") + bankLabel, p.mode,
                if (incoming) 0L else p.amountPaise, if (incoming) p.amountPaise else 0L)
        }
        salaryPayments.filter { it.dateEpochMillis in fromEpochMillis..toEpochMillis }.forEach { salary ->
            val employeeName = employees[salary.employeeId] ?: "कर्मचारी #${salary.employeeId}"
            val bankLabel = if (salary.mode == "BANK") salary.bankAccountId?.let(bankNames::get)?.let { " — $it" }.orEmpty() else ""
            all += DayBookRow(salary.dateEpochMillis, "SAL-${salary.id}", "वेतन भुगतान — $employeeName$bankLabel", salary.mode, salary.amountPaise, 0L)
        }
        cashEntries.filter { it.dateEpochMillis in fromEpochMillis..toEpochMillis }.forEach { e ->
            val inflow = e.entryType == "OPENING" || e.entryType == "CASH_WITHDRAWAL"
            val bankLabel = e.bankAccountId?.let(bankNames::get)?.let { " — $it" }
                ?: if (e.entryType in setOf("CASH_DEPOSIT", "CASH_WITHDRAWAL") || e.mode == "BANK") " — बैंक खाता उपलब्ध नहीं" else ""
            val description = when (e.entryType) {
                "OPENING" -> "Opening Balance (${e.mode})$bankLabel"
                "EXPENSE" -> "व्यापार खर्च (${e.mode})$bankLabel"
                "CASH_DEPOSIT" -> "Cash से Bank में जमा$bankLabel"
                "CASH_WITHDRAWAL" -> "Bank से Cash निकासी$bankLabel"
                else -> "अन्य कैश/बैंक एंट्री (${e.entryType})$bankLabel"
            }
            val displayMode = when (e.entryType) {
                "CASH_DEPOSIT" -> "CASH → BANK"
                "CASH_WITHDRAWAL" -> "BANK → CASH"
                else -> e.mode
            }
            all += DayBookRow(e.dateEpochMillis, "CASH-${e.id}", description, displayMode,
                if (inflow) 0L else e.amountPaise, if (inflow) e.amountPaise else 0L)
        }
        val ordered = all.sortedWith(compareBy<DayBookRow> { it.dateEpochMillis }.thenBy { it.reference })
        // Cash balance is based only on cash movements, not credit invoices or UPI/Bank transfers.
        val priorCashPayments = payments.filter { it.mode == "CASH" && it.dateEpochMillis < fromEpochMillis }
        val priorCashEntries = cashEntries.filter { it.mode == "CASH" && it.dateEpochMillis < fromEpochMillis }
        val priorSalaryCash = salaryPayments.filter { it.mode == "CASH" && it.dateEpochMillis < fromEpochMillis }.sumOf { it.amountPaise }
        val opening = priorCashPayments.sumOf { if (it.direction == "IN") it.amountPaise else -it.amountPaise } +
            priorCashEntries.sumOf { when (it.entryType) { "OPENING", "CASH_WITHDRAWAL" -> it.amountPaise; else -> -it.amountPaise } } - priorSalaryCash
        val periodCashIn = payments.filter { it.mode == "CASH" && it.dateEpochMillis in fromEpochMillis..toEpochMillis && it.direction == "IN" }.sumOf { it.amountPaise } +
            cashEntries.filter { it.mode == "CASH" && it.dateEpochMillis in fromEpochMillis..toEpochMillis && it.entryType in setOf("OPENING", "CASH_WITHDRAWAL") }.sumOf { it.amountPaise }
        val periodSalaryCash = salaryPayments.filter { it.mode == "CASH" && it.dateEpochMillis in fromEpochMillis..toEpochMillis }.sumOf { it.amountPaise }
        val periodCashOut = payments.filter { it.mode == "CASH" && it.dateEpochMillis in fromEpochMillis..toEpochMillis && it.direction == "OUT" }.sumOf { it.amountPaise } +
            cashEntries.filter { it.mode == "CASH" && it.dateEpochMillis in fromEpochMillis..toEpochMillis && it.entryType !in setOf("OPENING", "CASH_WITHDRAWAL") }.sumOf { it.amountPaise } + periodSalaryCash
        return DayBookSummary(opening, periodCashIn, periodCashOut, opening + periodCashIn - periodCashOut, ordered)
    }
}
