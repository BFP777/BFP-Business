"""Run every offline/source-level regression check shipped with BFP Business Pro."""
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = [
    "tools/verify_dev39_ui_bank.py",
    "tools/verify_dev40_bank_linking.py",
    "tools/verify_dev41_bank_balances.py",
    "tools/verify_dev42_daybook_bank_names.py",
    "tools/verify_dev43_separate_expense_bank.py",
    "tools/verify_dev44_inventory.py",
    "tools/verify_dev45_purchase_attachments.py",
    "tools/verify_dev46_employee_payroll.py",
    "tools/verify_dev47_smart_stock.py",
    "tools/verify_dev48_supplier_bill_ocr.py",
    "tools/verify_dev49_supplier_bill_lines.py",
    "tools/verify_dev50_supplier_bill_verification.py",
    "tools/verify_dev51_duplicate_purchase.py",
    "tools/verify_dev52_supplier_insights.py",
    "tools/verify_dev53_customer_intelligence.py",
    "tools/verify_dev54_customer_relationship.py",
    "tools/verify_dev55_customer_tabs.py",
    "tools/verify_dev56_bilingual_and_colors.py",
    "tools/verify_dev57_voice_scanner.py",
    "tools/verify_dev58_profit_deadstock.py",
    "tools/verify_dev59_business_dashboard.py",
    "tools/verify_dev60_business_trends.py",
    "tools/verify_dev61_ai_business_intelligence.py",
    "tools/verify_dev62_ai_demand_forecast.py",
    "tools/verify_dev63_profit_cashflow.py",
    "tools/verify_dev64_decision_assistant.py",
    "tools/verify_dev34_build_readiness.py",
    "tools/verify_package_hygiene.py",
    "tools/verify_room_dao_sql.py",
    "tools/verify_invoice_number_sql.py",
    "tools/verify_posting_invariants.py",
    "tools/verify_dev33_integrated_audit.py",
    "tools_verify_daybook.py",
    "tools_verify_dev30_source.py",
]
for script in SCRIPTS:
    print(f"\n>>> {script}", flush=True)
    subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)

ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
print("\nAndroidManifest XML parse: PASS")

app_gradle = (ROOT / "app/build.gradle.kts").read_text()
workflow = (ROOT / ".github/workflows/android-build.yml").read_text()
assert 'arg("room.schemaLocation", "$projectDir/schemas")' in app_gradle
assert "python3 tools/verify_all.py" in workflow
assert "gradle-version: 8.9" in workflow
assert "java-version: '17'" in workflow
print("Room schema export + CI regression hook: PASS")
print("BFP Business Pro offline verification suite: PASS")


subprocess.run([sys.executable, str(ROOT / 'tools/verify_dev67_sale_customer_picker.py')], cwd=ROOT, check=True)
