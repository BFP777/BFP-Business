from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/in/bhajan/bfpbusinesspro/MainActivity.kt").read_text()
checks = {
    "continuous voice mode starts from invoice item row": 'text = "🎙 लगातार बोलकर आइटम जोड़ें"' in main and "continuousVoiceEntry = true" in main,
    "recognized phrase fills item name and optional rate separately": "parseVoiceItemPhrase(spoken)" in main and "name.setText(parsed.first)" in main and "rate.setText(it)" in main,
    "continuous mode adds next draft row and resumes listening": "if (continuousVoiceEntry)" in main and "addLine()" in main and "startNextVoiceEntry?.invoke()" in main,
    "stop control ends continuous voice mode": 'text = "■ Voice Entry रोकें"' in main and "continuousVoiceEntry = false" in main,
    "English remains default without per-entry language dialog": 'getString("voice_input_language", "en-IN")' in main and "showVoiceInputLanguageSettings" in main,
    "Hindi and English number phrases supported": '"पाँच" to 5L' in main and '"five" to 5L' in main and '"सौ"' in main and '"hundred"' in main,
    "voice result remains draft-only; existing explicit invoice save remains required": "pendingVoiceHandler?.invoke(spoken)" in main and "dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener" in main,
    "voice loop is stopped when invoice dialog closes": "continuousVoiceEntry = false" in main and "dialog.setOnDismissListener" in main,
    "version advanced to 5.22.0": 'versionCode = 522' in (root / "app/build.gradle.kts").read_text() and 'versionName = "5.22.0"' in (root / "app/build.gradle.kts").read_text(),
}
for label, ok in checks.items(): print(f"{'PASS' if ok else 'FAIL'}: {label}")
assert all(checks.values())
print("Development 74 Voice Billing checks: PASS")
